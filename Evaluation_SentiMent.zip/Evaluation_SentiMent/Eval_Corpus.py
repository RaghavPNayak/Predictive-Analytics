import re, math, collections, itertools, os
import nltk, nltk.classify.util, nltk.metrics
from nltk.classify import NaiveBayesClassifier
from nltk.metrics import BigramAssocMeasures
from nltk.probability import FreqDist, ConditionalFreqDist
from nltk.metrics import precision
from nltk.metrics import recall
from nltk.metrics import f_measure


#Evaluaion of the training corpus
def evaluate_features(feature_select):
	posFeatures = []
	negFeatures = []
	posFeatures1 = []
	negFeatures1 = []
	
	with open('positive.txt', 'r') as posSentences:
		for i in posSentences:
			posWords = re.findall(r"[\w']+|[.,!?;]", i.rstrip())
			posWords = [feature_select(posWords), 'pos']
			posFeatures.append(posWords)
	with open('negative.txt', 'r') as negSentences:
		for i in negSentences:
			negWords = re.findall(r"[\w']+|[.,!?;]", i.rstrip())
			negWords = [feature_select(negWords), 'neg']
			negFeatures.append(negWords)
	
	with open('TMWKIPosTweets.txt', 'r') as posSentences1:
		for i in posSentences1:
			posWords1 = re.findall(r"[\w']+|[.,!?;]", i.rstrip())
			posWords1 = [feature_select(posWords1), 'pos']
			posFeatures1.append(posWords1)
	with open('TMWKINegTweets.txt', 'r') as negSentences1:
		for i in negSentences1:
			negWords1 = re.findall(r"[\w']+|[.,!?;]", i.rstrip())
			negWords1 = [feature_select(negWords1), 'neg']
			negFeatures1.append(negWords1)

	
	
	trainFeatures = posFeatures + negFeatures
	testFeatures = posFeatures1 + negFeatures1

	classifier = NaiveBayesClassifier.train(trainFeatures)	

	referenceSets = collections.defaultdict(set)
	testSets = collections.defaultdict(set)	

	for i, (features, label) in enumerate(testFeatures):
		referenceSets[label].add(i)
		predicted = classifier.classify(features)
		testSets[predicted].add(i)

	a = len(trainFeatures)
	a1 = len(testFeatures)
	b = nltk.classify.util.accuracy(classifier, testFeatures)
	c = precision(referenceSets['pos'], testSets['pos'])
	d = precision(referenceSets['neg'], testSets['neg'])
	e = recall(referenceSets['pos'], testSets['pos'])
	f = recall(referenceSets['neg'], testSets['neg'])
	g = f_measure(referenceSets['pos'], testSets['pos'], alpha=0.5)
	h = f_measure(referenceSets['neg'], testSets['neg'], alpha=0.5)
	print ('Trained on %d Tweets, Tested on %d Tweets', a,a1)
	print ('Sentiment Analysis - Bayesian Classifier - Accuracy:', b)
	print ('Positive Tweets - Precision:', c)
	print ('Positive Tweets - Recall:', d)
	print ('Negative Tweets - Precision:', e)
	print ('Negative Tweets - Recall:', f)
	print ('Positive Tweets - F_measure:',g)
	print ('Negative Tweets - F_measure:',h)

	file1 = open('Evaluation_Result.txt','w')
	file1.write('Evaluation performed on NLTKPang/Lee Movie Corpus - 10000 reviews')
	file1.write('\n')
	file1.write('Evaluation of the training corpus - for Naive Bayes Classifier')
	file1.write('\n')
	file1.write('Trained on ')
	file1.write(str(a))
	file1.write(' Tweets, Tested on ')
	file1.write(str(a1))
	file1.write('Tweets')
	file1.write('\n')
	file1.write('Sentiment Analysis (Bayesian Classifier) Accuracy: ')
	file1.write(str(b))
	file1.write('\n')
	file1.write('Pos Tweets - Precision: ')
	file1.write(str(c))
	file1.write('\n')
	file1.write('Neg Tweets - Precision: ')
	file1.write(str(d))
	file1.write('\n')
	file1.write('Pos Tweets - Recall: ')
	file1.write(str(e))
	file1.write('\n')
	file1.write('Neg Tweets - Recall: ')
	file1.write(str(f))
	file1.write('\n')
	file1.write('Pos Tweets - Fmeasure: ')
	file1.write(str(g))
	file1.write('\n')
	file1.write('Neg Tweets - Fmeasure: ')
	file1.write(str(h))
	file1.write('\n')
	file1.close()

def make_full_dict(words):
	return dict([(word, True) for word in words])


print ('Evaluation performed on NLTKPang/Lee Movie Corpus - 10000 reviews')
print ('Evaluation of the training corpus - for Naive Bayes Classifier')
evaluate_features(make_full_dict)


